<?php

$pdo = new PDO('mysql:host=dwarves.iut-fbleau.fr;dbname=carlu', 'carlu', 'ludo1811');
 
?>